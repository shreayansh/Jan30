package release;

import java.util.Arrays;

public class Arrays1
{
    public static void main(String[] args) {

        
        Student student = new Student();
        student.name = "Guddu";
        student.rollNo = 123;
        
        
        Student[] students = new Student[47];
     //   students[0] = new Student();
     //   students[0].rollNo = 1;
     //   students[0].name = "Bablu";

        for (int i = 0; i < students.length ; i++)
        {
            students[i] = new Student();
            students[i].rollNo = i + 1;
            students[i].name = "guddu" + 1;
        }

        /*for (Student student1 : students)
        {
            System.out.println(student1);
        }*/

        for (int i = 0; i < students.length; i++)
        {
            System.out.println(students[i]);

        }
        System.out.println();
        
    }
}

class Student
{
    int rollNo;
    String name;

    @Override
    public String toString()
    {
        return ("("rollNo + " , " + name +" )" ) ;

    }
}

