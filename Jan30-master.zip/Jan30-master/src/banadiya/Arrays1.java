package banadiya;

import java.util.Arrays;

public class Arrays1
{

    private Student[] studentArray;
    private int bottom;

    Arrays1(int numberOfStudents)
    {
        studentArray = new Student[numberOfStudents];
        bottom = -1;

    }

    private void insert(Student student)
    {
        if(bottom != studentArray.length - 1)
        {
            bottom++;
            studentArray[bottom] = student;
        }
    }


    public static void main(String[] args) {
        Arrays1 list = new Arrays1(47);
        Studentstudent = new Student();
        student.setRollNo(1);
        student.setName("Guddu");
        list.insert(student)
        System.out.println(Arrays.toString(list.studentArray));
    }


    public static void main(String[] args) {
        Arrays1 list = new Arrays1(47);
        list.insert(new Student());
    }

    public static void main(String[] args) {
        Student student = new Student();
        student.setRollNo(1);
        student.setName("Kaalin Bhaiaya");
        System.out.println(student);
    }
}

class Student
{
    private int rollNo;
    private String name;

    // getters & setters
    // accessors & mutators
    // observers & transformers

    public int getRollNo()
    {
        return rollNo;
    }

    public String getName()
    {
        return name;
    }


    public void setRollNo(int rollNo)
    {
        this.rollNo = rollNo;

    }

    public void setName(String name)
    {
        this.name = name;
    }

    @Override
    public String toString() {
        return ("(" + rollNo + " , " + name + ")");
    }
}